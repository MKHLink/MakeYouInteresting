package com.example.Practice.demo.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@Table(name="user_table")
public class User {
    @Id
    @GeneratedValue
    private Long id;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name="username",column=@Column(nullable = false,unique = true)),
    @AttributeOverride(name="password",column = @Column(nullable = false)) })
    private Credentials credentials;

    @Embedded
    @AttributeOverrides({@AttributeOverride(name="firstName",column = @Column(nullable = false, unique = false)),
    @AttributeOverride(name="lastName",column = @Column(nullable = false,unique = false)),
    @AttributeOverride(name="email",column = @Column(nullable = false,unique = true)),
    @AttributeOverride(name="phone",column = @Column(nullable = false,unique = false)) })
    private Profile profile;

    @CreationTimestamp
    private Date joined;

    private boolean deleted;

    @ManyToMany
    private List<Interests> interests = new ArrayList<>();

}
